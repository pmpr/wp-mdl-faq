<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400d642f3d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\Container\ComponentInitiator; use Pmpr\Module\FAQ\Model\Model; class FAQ extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\106\101\121", PR__MDL__FAQ); }]); } public function mameiwsayuyquoeq() { Page::symcgieuakksimmu(); Model::symcgieuakksimmu(); if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto csscmcacoikwsecs; } Setting::symcgieuakksimmu(); csscmcacoikwsecs: } }
