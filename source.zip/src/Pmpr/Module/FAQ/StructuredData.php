<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7218c7feb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Module\StructuredData\AbstractStructuredData; class StructuredData extends AbstractStructuredData { }
