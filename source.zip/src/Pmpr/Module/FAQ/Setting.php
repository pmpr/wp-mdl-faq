<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65fff696e28c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(self::qoquaeuooeycomks, $this->mwikyscisascoeea()); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\106\x41\121\x20\x53\x65\x74\x74\151\156\x67", PR__MDL__FAQ); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\x65\x74\164\151\156\x67", PR__MDL__FAQ)); } }
