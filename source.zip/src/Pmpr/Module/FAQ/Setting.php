<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870808a604a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(self::qoquaeuooeycomks, $this->mwikyscisascoeea()); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x46\x41\121\40\x53\x65\x74\x74\151\x6e\147", PR__MDL__FAQ); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\123\x65\164\x74\x69\156\147", PR__MDL__FAQ)); } }
