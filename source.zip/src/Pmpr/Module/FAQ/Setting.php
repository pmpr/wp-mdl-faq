<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41b419a32             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(self::qoquaeuooeycomks, $this->mwikyscisascoeea()); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x46\x41\x51\x20\x53\x65\164\164\x69\x6e\x67", PR__MDL__FAQ); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\145\164\164\151\156\147", PR__MDL__FAQ)); } }
