<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec708a34b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(Constants::qoquaeuooeycomks, $this->mwikyscisascoeea()); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\106\101\121\40\x53\x65\x74\x74\x69\156\147", PR__MDL__FAQ); $this->igiywquyccyiaucw(Constants::qsegwakiwaiyimyy, __("\x53\x65\x74\x74\151\156\x67", PR__MDL__FAQ)); } }
