<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65fee42a1bacd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting as BaseClass; class Setting extends BaseClass { public function qiccuiwooiquycsg() { $this->id = $this->akuociswqmoigkas(); $this->igiywquyccyiaucw(self::qoquaeuooeycomks, $this->mwikyscisascoeea()); parent::qiccuiwooiquycsg(); } public function wyyuauosmqoeucmg() { $this->title = __("\x46\x41\121\40\x53\145\x74\164\x69\156\x67", PR__MDL__FAQ); $this->igiywquyccyiaucw(self::qsegwakiwaiyimyy, __("\x53\145\x74\x74\x69\156\x67", PR__MDL__FAQ)); } }
