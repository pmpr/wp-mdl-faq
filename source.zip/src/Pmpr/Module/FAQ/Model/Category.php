<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66870808a604a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Category extends Common { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::uaimoioocayauuca)->wiskakymeaywyeuw(self::akuociswqmoigkas())->guiaswksukmgageq(__("\x43\141\x74\145\147\157\x72\171", PR__MDL__FAQ))->muuwuqssqkaieqge(__("\x43\x61\164\x65\147\157\162\x69\145\x73", PR__MDL__FAQ))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->gysoeyaguiyewoes(self::NAME)->gswweykyogmsyawy(__("\x4e\141\155\x65", PR__MDL__FAQ)), $this->qoemykoeuecmsmwe(self::iuqumwggccmcuyem)->gswweykyogmsyawy(__("\x50\x72\x69\x6f\x72\x69\164\x79", PR__MDL__FAQ))->eyygsasuqmommkua(0), $this->eoaomaokwkwqyqiq(self::qaouquqcwsmaaoow)->gswweykyogmsyawy(__("\103\x61\164\145\147\157\x72\x79", PR__MDL__FAQ))->ckgquisaimmgwuyu()]); parent::ewaqwooqoqmcoomi(); } }
