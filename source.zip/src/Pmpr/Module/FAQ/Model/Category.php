<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce1188ac663             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Category extends Common { public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->myysgyqcumekoueo()->yioesawwewqaigow(IconInterface::uaimoioocayauuca)->wiskakymeaywyeuw($this->akuociswqmoigkas())->guiaswksukmgageq(__("\x43\141\x74\145\147\x6f\x72\x79", PR__MDL__FAQ))->muuwuqssqkaieqge(__("\x43\x61\x74\145\147\x6f\162\151\145\x73", PR__MDL__FAQ))->gemkqqguesukeocw()->aseucqksocwomwos()->wkesqcmiekqoykag()->qemeyueyiwgsokuc(); } public function ewaqwooqoqmcoomi() { $this->ckaemmoueyosqqkq([$this->gysoeyaguiyewoes(Constants::NAME)->gswweykyogmsyawy(__("\116\x61\x6d\x65", PR__MDL__FAQ)), $this->qoemykoeuecmsmwe(Constants::iuqumwggccmcuyem)->gswweykyogmsyawy(__("\x50\x72\x69\x6f\162\151\164\171", PR__MDL__FAQ))->eyygsasuqmommkua(0), $this->eoaomaokwkwqyqiq(self::qaouquqcwsmaaoow)->gswweykyogmsyawy(__("\x43\141\x74\x65\x67\157\162\171", PR__MDL__FAQ))->ckgquisaimmgwuyu()]); parent::ewaqwooqoqmcoomi(); } }
