<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65fff696e28c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { const qweekaqwsewcacci = "\x71\165\x65\x73\164\151\x6f\x6e\x5f\151\x64"; const qaouquqcwsmaaoow = "\143\141\164\145\147\157\x72\x79\x5f\151\x64"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm(self::akuociswqmoigkas()); } }
