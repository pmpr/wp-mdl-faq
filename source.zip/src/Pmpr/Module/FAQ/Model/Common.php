<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a884f2978             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { const qweekaqwsewcacci = "\161\x75\145\x73\164\x69\x6f\156\137\151\x64"; const qaouquqcwsmaaoow = "\x63\141\164\x65\147\157\x72\x79\x5f\x69\144"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm(self::akuociswqmoigkas()); } }
