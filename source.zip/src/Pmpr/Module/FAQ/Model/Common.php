<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65fff5598e3e6             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Common\Foundation\ORM\DB\Model; abstract class Common extends Model { const qweekaqwsewcacci = "\161\x75\x65\x73\x74\x69\x6f\156\137\151\144"; const qaouquqcwsmaaoow = "\x63\x61\164\145\147\x6f\162\171\137\x69\144"; public function ckgmycmaukqgkosk() { parent::ckgmycmaukqgkosk(); $this->oyeskqayoscwciem()->okgmqaeuaeymaocm(self::akuociswqmoigkas()); } }
