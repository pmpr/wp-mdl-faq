<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a884f2978             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Module\FAQ\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Question::symcgieuakksimmu(); } }
