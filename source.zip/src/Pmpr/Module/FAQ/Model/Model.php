<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65fee42a1bacd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Module\FAQ\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Question::symcgieuakksimmu(); } }
