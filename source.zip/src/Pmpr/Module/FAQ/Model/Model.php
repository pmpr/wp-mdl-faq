<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8ed54b57             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Module\FAQ\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Question::symcgieuakksimmu(); } }
