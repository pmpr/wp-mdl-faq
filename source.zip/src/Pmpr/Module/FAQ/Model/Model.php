<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             65fff696e28c0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\FAQ\Model; use Pmpr\Module\FAQ\Container; class Model extends Container { public function aqyikqugcomoqqqi() { Question::symcgieuakksimmu(); } }
