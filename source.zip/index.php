<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc7218c7feb             |
    |_______________________________________|
*/
 use Pmpr\Module\FAQ\FAQ; FAQ::symcgieuakksimmu();
