<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a884f2978             |
    |_______________________________________|
*/
 use Pmpr\Module\FAQ\FAQ; FAQ::symcgieuakksimmu();
